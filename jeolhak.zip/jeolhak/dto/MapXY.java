package com.jeolhak.jeolhak.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MapXY {
    private double x;
    private double y;
}