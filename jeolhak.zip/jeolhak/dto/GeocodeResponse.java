package com.jeolhak.jeolhak.dto;

import java.util.List;
import lombok.Data;

@Data
public class GeocodeResponse {
    private List<Document> documents;

    @Data
    public static class Document {
        private String x;
        private String y;
    }
}
