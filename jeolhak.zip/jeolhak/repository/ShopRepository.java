package com.jeolhak.jeolhak.repository;

import com.jeolhak.jeolhak.domain.Shop;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShopRepository extends JpaRepository<Shop, Long> {}