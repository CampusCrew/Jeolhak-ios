package com.jeolhak.jeolhak;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // 이 클래스는 API 응답을 보내는 클래스다!
public class HyejinGaeuncollab {

    @GetMapping("/hello") // GET 방식으로 /hello 주소가 오면
    public String hello() {
        return "Hello, world!";
    }
}