package com.jeolhak.jeolhak.controller;

import com.jeolhak.jeolhak.domain.Shop;
import com.jeolhak.jeolhak.service.ShopService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import java.util.List;

@RestController
@RequestMapping("/api/shops")
@RequiredArgsConstructor
public class ShopController {
    private final ShopService shopService;

    @GetMapping
    public List<Shop> all() {
        return shopService.getAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Shop> one(@PathVariable Long id) {
        Shop shop = shopService.getOne(id);
        return shop != null ? ResponseEntity.ok(shop) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public Shop create(@RequestBody Shop shop) {
        return shopService.create(shop);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        shopService.delete(id);
    }
}