package com.jeolhak.jeolhak.controller;

import com.jeolhak.jeolhak.service.GeocodingService;
import com.jeolhak.jeolhak.dto.MapXY;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/api/geocoding")
@RequiredArgsConstructor
public class GeocodingController {
    private final GeocodingService geocodingService;

    @PostMapping
    public MapXY geocode(@RequestBody Map<String, String> request) {
        return geocodingService.geocode(request.get("address"));
    }
}
