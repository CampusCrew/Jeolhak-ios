package com.jeolhak.jeolhak.service;

import com.jeolhak.jeolhak.dto.GeocodeResponse;
import com.jeolhak.jeolhak.dto.MapXY;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class GeocodingService {
    private final WebClient webClient;

    @Value("${kakao.api.key}")
    private String apiKey;

    public MapXY geocode(String address) {
        GeocodeResponse response = webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/v2/local/search/address.json")
                        .queryParam("query", address)
                        .build())
                .header("Authorization", "KakaoAK " + apiKey)
                .retrieve()
                .bodyToMono(GeocodeResponse.class)
                .block();

        if (response != null && !response.getDocuments().isEmpty()) {
            var doc = response.getDocuments().get(0);
            return new MapXY(Double.parseDouble(doc.getX()), Double.parseDouble(doc.getY()));
        }
        return null;
    }
}
