
package com.jeolhak.jeolhak.service;

import com.jeolhak.jeolhak.domain.Shop;
import com.jeolhak.jeolhak.repository.ShopRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ShopService {
    private final ShopRepository shopRepository;

    public List<Shop> getAll() {
        return shopRepository.findAll();
    }

    public Shop getOne(Long id) {
        return shopRepository.findById(id).orElse(null);
    }

    public Shop create(Shop shop) {
        return shopRepository.save(shop);
    }

    public void delete(Long id) {
        shopRepository.deleteById(id);
    }
}

