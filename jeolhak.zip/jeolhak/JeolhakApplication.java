package com.jeolhak.jeolhak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
public class JeolhakApplication {

    public static void main(String[] args) {
        SpringApplication.run(JeolhakApplication.class, args);
    }

}
